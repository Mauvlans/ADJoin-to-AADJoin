$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
$Secure = $tsenv.Value("TempUserPassword")
$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
$User = $tsenv.Value("TempUser")

$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
Set-ItemProperty $RegPath "AutoAdminLogon" -Value "1" -type String 
Set-ItemProperty $RegPath "DefaultUsername" -Value "$User" -type String 
Set-ItemProperty $RegPath "DefaultPassword" -Value "$Secure" -type String