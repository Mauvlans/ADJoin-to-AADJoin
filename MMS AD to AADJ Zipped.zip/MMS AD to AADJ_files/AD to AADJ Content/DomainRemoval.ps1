

# Remove Machines from AD
Write-Verbose "Removing computer from domain and forcing restart"
$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
$pw = $tsenv.Value("DomainAdminPassword") | ConvertTo-SecureString -asPlainText -Force
$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
$usr = $tsenv.Value("DomainAdmin")
$pc = "localhost"
$creds = New-Object System.Management.Automation.PSCredential($usr,$pw)
Remove-Computer -ComputerName $pc -Credential $creds �Verbose �Force