$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
# Create Local Account 
Write-Output "Removing Local User Account"
$User = $tsenv.Value("TempUser")
Remove-LocalUser -Name $User