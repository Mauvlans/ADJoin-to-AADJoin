$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment
# Create Local Account 
Write-Output "Creating Local User Account"
$Secure = $tsenv.Value("TempUserPassword")
$Password = ConvertTo-SecureString -AsPlainText $Secure -force
$User = $tsenv.Value("TempUser")
New-LocalUser -Name $User -Password $Password -Description "account for autologin" -AccountNeverExpires
Add-LocalGroupMember -Group "Administrators" -Member $User